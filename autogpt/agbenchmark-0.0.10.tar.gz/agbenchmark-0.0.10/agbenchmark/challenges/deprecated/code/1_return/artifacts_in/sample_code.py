def multiply_int(num: int) -> int:
    multiplied_num = num * 2
